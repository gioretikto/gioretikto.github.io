#include <gtk/gtk.h>
#include "litos.h"

extern void activate (GtkApplication* app, gpointer user_data);
void open_file_cb (GObject *source_object, GAsyncResult *res, gpointer userData);

static void
app_open (GApplication  *app,
		GFile        **files,
		gint           n_files,
		gchar* hint,
		gpointer userData)
{
	(void) app;
	(void) hint;

	int i;

	struct lit *litos = (struct lit*)userData;

	for (i = 0; i < n_files; i++)
    {
		open_file_cb (G_OBJECT(files[i]), NULL, litos);
    }
}

int
main (int    argc,
      char **argv)
{
	int status;

	GtkApplication* app;

	struct lit litos;

	int i;

	for (i = 0; i < MAX_TAB; i++)
	{
		litos.fileSaved[i] = TRUE;
		litos.filename[i] = NULL;
	}

	litos.search_context = NULL;

	app = gtk_application_new ("org.litos.gtk", G_APPLICATION_HANDLES_OPEN);

	g_signal_connect (app, "activate", G_CALLBACK (activate), &litos);

	g_signal_connect (app, "open", G_CALLBACK (app_open), &litos);

	status = g_application_run (G_APPLICATION (app), argc, argv);

	g_object_unref (app);

	return status;
}
