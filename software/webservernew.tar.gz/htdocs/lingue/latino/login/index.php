<?php
    include_once 'includes/db_connect.php';
    include_once 'includes/functions.php';
    
    sec_session_start();
    
    if (login_check($mysqli) == true) {
        $logged = 'in';
        
    } else {
        $logged = 'out';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

    <title>Secure Login: Log In</title>

    <link rel="stylesheet" type="text/css" href="../style.css" media="screen">

    <script type="text/JavaScript" src="js/sha512.js"></script> 
    <script type="text/JavaScript" src="js/forms.js"></script> 
</head>

<body>

    <nav>
        <ul>
            <li><a class="navbar" href="../index.php">Latin-Dictionary</a></li>
            <li><a class="navbar" href="../grammar/index.html">Grammar</a></li>
            <li><a class="navbar" href="index.php">Sign in</a></li>
        </ul>
   </nav>
    
<div class="content">

    <h1>Sign in</h1>
    
      <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">Wrong password or username!</p>';
        }
        ?>
        
     <form action="includes/process_login.php" method="post" name="login_form">                      
            Email: <input type="text" name="email" />
            Password: <input type="password"  name="password" id="password"/>
            <input type="button"  value="Login"  onclick="formhash(this.form, this.form.password);" /> 
        </form>
 
  <p>Don’t have a Latine account? <a href="register.php" alt="registrati">Register Now</a>

  </div>
  
</body>
</html>
