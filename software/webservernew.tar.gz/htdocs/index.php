<?php 

    include_once 'login/includes/functions.php';
    sec_session_start();
    
    ini_set('display_errors', 'On');
    error_reporting(-1); 
    
    ?>

<!DOCTYPE html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

<title>thescientist.it - Dove gli scienziati imparano, scambiano idee , &amp; fanno carriera</title>

<link rel="stylesheet" type="text/css" href="css/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="css/theme-medium.css" media="screen">
<link rel="stylesheet" type="text/css" href="css/home.css" media="screen">

</head>
<body class="home ">

<nav id="head-nav" class="navbar navbar-fixed-top">

  <div class="navbar-inner clearfix">
    <ul class="nav">
    <li><a href="index.php" class="brand">Home</a></li>
      <li class=""><a href="documentation.html">Documentation</a></li>
      <li class=""><a href="annunci/index.php">Questions</a></li>
      <li><a href="lingue/dizlat/index.php" title="Latin English Dictionary">Latin-English Dictionary</a></li>
    </ul>

    
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
    
     <?php
                if (isset($_SESSION['logged']))
                             echo '<div style="float:right; margin-right:50px";"> <a href="login/includes/logout.php" style="text-decoration:none"><img  src="img/login.png" alt="effettua il login"/> logout '. $_SESSION['username']. '</a></div>';
                else
                     echo '<div style="float:right; margin-right:50px;"> <a href="/login/" class="button">Log In</a></div>';
    ?>
    
  </div>
  
  
  <div id="flash-message"></div>
</nav>



<div id="intro" class="clearfix">
  <div class="container">
      <div class="row clearfix">
      
    <div class="blurb">
      <p>PHP is a popular general-purpose scripting language that is especially suited to web development.</p>
      <p>Fast, flexible and pragmatic, PHP powers everything from your blog to the most popular websites in the world.</p>
    </div>
    
    <div class="download">
      <h3>Download</h3><ul>

            <li><a class='download-link' href='/downloads.php#v5.6.31'>5.6.31</a><span class='dot'>&middot;</span><a class='notes' href='/ChangeLog-5.php#5.6.31'>Release Notes</a><span class='dot'>&middot;</span><a class='notes' href='/migration56'>Upgrading</a></li>

            <li><a class='download-link' href='/downloads.php#v7.0.21'>7.0.21</a><span class='dot'>&middot;</span><a class='notes' href='/ChangeLog-7.php#7.0.21'>Release Notes</a><span class='dot'>&middot;</span><a class='notes' href='/migration70'>Upgrading</a></li>

            <li><a class='download-link' href='/downloads.php#v7.1.7'>7.1.7</a><span class='dot'>&middot;</span><a class='notes' href='/ChangeLog-7.php#7.1.7'>Release Notes</a><span class='dot'>&middot;</span><a class='notes' href='/migration71'>Upgrading</a></li>
</ul>
    </div>
  </div>  </div>
</div>


<div id="layout" class="clearfix">
  <section id="layout-content">
<div class='home-content'>
<article class="newsentry">
  <header class="title"> <h2 class="newstitle"> Chiedi la soluzione di un problema</h2></header>
  
  <div class="newscontent">
    <div>
     <form method="post" enctype="multipart/form-data" action="<?php if (isset($_SESSION['logged'])) echo 'file_upload.php'; else echo 'index.php';?>">
         <?php if (!isset($_SESSION['logged']) && !isset($_POST['content']))  echo '<p>Effettua il <a href="login/index.php">Login</a> per iniziare</p>'; 
                if ( !isset($_SESSION['logged']) && isset($_POST['content']))  echo '<p style="color:red">Devi prima effettuare il <a href="login/index.php">Login</a> per rispondere</p>'; ?>
                <table>
                <tr>
                    <td width="250"></td>
                    <td id="mainselection">
                    
                    <select name="type" id="type" valure="Ambito">
                        <option>Ambito</option>
                        <option value="chimica">Chimica</option>
                        <option value="fisica">Fisica</option>
                        <option value="termodinamica">Termodinamica</option>
                        <option value="analisi">Analisi Matematica</option>
                    </select>
                
                    </td>
                </tr>
                          
                <tr>
                <td width="250"></td>
                <td>
                <textarea id="content" name="content" rows="10" cols="50" style="border-style:groove;box-shadow: 4px 4px 4px 4px #888888;" placeholder="Descrivi concisamente il problema o domanda"></textarea>
                </td>
                </tr>
                
                                
                <tr>
                <td width="250">Allega un'immagine</td>
                <td>
                <input name="image" type="file" id="file">
                </td>
                </tr>

                <tr>
                <td width="250"> </td>
                <td>
                <input name="add" type="submit" id="add" value="Invia" >
                </td>
                </tr>
                <tr>
                
                </table>
            </form>
    </div>
  
  </div>
</article>

<article class="newsentry">
  <header class="title">
    <time datetime="2017-07-06T15:03:21-07:00">06 Jul 2017</time>
    <h2 class="newstitle">
      <a href="http://epsilonzero.it/archive/2017.php#id2017-07-06-4" id="id2017-07-06-4">PHP 5.6.31 Released</a>
    </h2>
  </header>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     5.6.31. This is a security release. Several security bugs were fixed in
     this release.

     All PHP 5.6 users are encouraged to upgrade to this version.</p>

     <p>For source downloads of PHP 5.6.31 please visit our <a href="http://www.epsilonzero.it/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.epsilonzero.it/download/">windows.epsilonzero.it/download/</a>.
     The list of changes is recorded in the <a href="http://www.epsilonzero.it/ChangeLog-5.php#5.6.31">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>

<article class="newsentry">
  <header class="title">
    <time datetime="2017-07-06T17:35:10+00:00">06 Jul 2017</time>
    <h2 class="newstitle">
      <a href="http://epsilonzero.it/archive/2017.php#id2017-07-06-3" id="id2017-07-06-3">PHP 7.1.7 Released</a>
    </h2>
  </header>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.7. This is a security release with several bug fixes included.

       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>

       <p>For source downloads of PHP 7.1.7 please visit our <a href="http://www.epsilonzero.it/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.epsilonzero.it/download/">windows.epsilonzero.it/download/</a>.
       The list of changes is recorded in the <a href="http://www.epsilonzero.it/ChangeLog-7.php#7.1.7">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article><article class="newsentry">
  <header class="title">
    <time datetime="2017-07-06T12:25:08+02:00">06 Jul 2017</time>
    <h2 class="newstitle">
      <a href="http://epsilonzero.it/archive/2017.php#id2017-07-06-2" id="id2017-07-06-2">PHP 7.2.0 Alpha 3 Released</a>
    </h2>
  </header>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP 7.2.0 Alpha 3.
     This release contains fixes and improvements relative to Alpha 2.
     All users of PHP are encouraged to test this version carefully,
     and report any bugs and incompatibilities in the
     <a href="https://bugs.epsilonzero.it/">bug tracking system</a>.</p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>For information on new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0alpha3/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0alpha3/UPGRADING">UPGRADING</a> file
     for a complete list of upgrading notes. These files can also be found in the release archive.</p>

     <p>For source downloads of PHP 7.2.0 Alpha 3 please visit the <a href="https://downloads.epsilonzero.it/~remi/">download</a> page,
     Windows sources and binaries can be found on <a href="http://windows.epsilonzero.it/qa/">windows.epsilonzero.it/qa/</a>.</p>

     <p>The first beta will be released on the 20th of July. You can also read the full list of planned releases on our
     <a href="https://wiki.epsilonzero.it/todo/php72#timetable">wiki</a>.</p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article><article class="newsentry">
  <header class="title">
    <time datetime="2017-07-06T13:00:00+01:00">06 Jul 2017</time>
    <h2 class="newstitle">
      <a href="http://epsilonzero.it/archive/2017.php#id2017-07-06-1" id="id2017-07-06-1">PHP 7.0.21 Released</a>
    </h2>
  </header>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     7.0.21. This is a security release. Several security bugs were fixed in
     this release.
     
     All PHP 7.0 users are encouraged to upgrade to this version.</p>
     
     <p>For source downloads of PHP 7.0.21 please visit our <a href="http://www.epsilonzero.it/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.epsilonzero.it/download/">windows.epsilonzero.it/download/</a>.
     The list of changes is recorded in the <a href="http://www.epsilonzero.it/ChangeLog-7.php#7.0.21">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article><article class="newsentry">
  <header class="title">
    <time datetime="2017-06-22T11:00:00+00:00">22 Jun 2017</time>
    <h2 class="newstitle">
      <a href="http://epsilonzero.it/archive/2017.php#id2017-06-22-1" id="id2017-06-22-1">PHP 7.2.0 Alpha 2 Released</a>
    </h2>
  </header>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP 7.2.0 Alpha 2.
     This release contains fixes and improvements relative to Alpha 1.
     All users of PHP are encouraged to test this version carefully,
     and report any bugs and incompatibilities in the
     <a href="https://bugs.epsilonzero.it/">bug tracking system</a>.</p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>For information on new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0alpha2/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0alpha2/UPGRADING">UPGRADING</a> file
     for a complete list of upgrading notes. These files can also be found in the release archive.</p>

     <p>For source downloads of PHP 7.2.0 Alpha 2 please visit the <a href="https://downloads.epsilonzero.it/~pollita/">download</a> page,
     Windows sources and binaries can be found on <a href="http://windows.epsilonzero.it/qa/">windows.epsilonzero.it/qa/</a>.</p>

     <p>The third and final alpha will be released on the 6th of July. You can also read the full list of planned releases on our
     <a href="https://wiki.epsilonzero.it/todo/php72#timetable">wiki</a>.</p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article><article class="newsentry">
  <header class="title">
    <time datetime="2017-06-08T19:40:06+00:00">08 Jun 2017</time>
    <h2 class="newstitle">
      <a href="http://epsilonzero.it/archive/2017.php#id2017-06-08-3" id="id2017-06-08-3">PHP 7.1.6 Released</a>
    </h2>
  </header>
  <div class="newscontent">
    <p xmlns="http://www.w3.org/2005/Atom">The PHP development team announces the immediate availability of PHP
      7.1.6. Several bugs have been fixed.
     
      All PHP 7.1 users are encouraged to upgrade to this version.
      </p>
     
	  <p xmlns="http://www.w3.org/2005/Atom">For source downloads of PHP 7.1.6 please visit our <a href="http://www.epsilonzero.it/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.epsilonzero.it/download/">windows.epsilonzero.it/download/</a>.
      The list of changes is recorded in the <a href="http://www.epsilonzero.it/ChangeLog-7.php#7.1.6">ChangeLog</a>.
      </p>
  
  </div>
</article><a href="/archive/">Older News Entries</a></div>    </section><!-- layout-content -->
    
    
<aside class="tips">
    <div class="inner">
<div class="panel">  <a href="/conferences" class="headline" title="Upcoming conferences">Upcoming conferences</a><div class="body"><ul><li><a href='http://epsilonzero.it/conferences/index.php#id2017-07-10-1' title='php[world] 2017'>php[world] 2017</a></li><li><a href='http://epsilonzero.it/conferences/index.php#id2017-06-29-1' title='PHP Developer Day 2017'>PHP Developer Day 2017</a></li><li><a href='http://epsilonzero.it/conferences/index.php#id2017-06-23-1' title='Forum PHP 2017'>Forum PHP 2017</a></li><li><a href='http://epsilonzero.it/conferences/index.php#id2017-02-24-1' title='Madison PHP Conference 2017'>Madison PHP Conference 2017</a></li></ul></div></div><div class="panel">  <a href="/conferences" class="headline" title="Conferences calling for papers">Dizionari</a><div
class="body"><ul><li><a href="lingue/dizlat/dizlat.php" title="Dizionario latino italiano">Dizionario Latino-italiano</a></li>
><ul><li><a href="lingue/dizlaten/dizlat.php" title="Latin English Dictionary">Latin-English Dictionary</a></li>
<li><a href='http://epsilonzero.it/conferences/index.php#id2017-06-14-1' title='ZendCon 2017'>ZendCon 2017</a></li><li><a href='http://epsilonzero.it/conferences/index.php#id2017-02-24-1' title='Madison PHP Conference 2017'>Madison PHP Conference 2017</a></li></ul></div></div>
    <p class='panel'><a href='/cal.php'>User Group Events</a></p>
    <p class='panel'><a href='/thanks.php'>Special Thanks</a></p>
    <p class='panel social-media'>
      <span class='headline'>Social media</span>
      <div class='body'>
        <ul>
          <li>
            <a href="https://twitter.com/official_php">
              <i class="icon-twitter"></i>
              @official_php
            </a>
          </li>
        </ul>
      </div>
    </p>
</div>
</aside>

  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2017 The epsilonzero Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

</body>
</html>
