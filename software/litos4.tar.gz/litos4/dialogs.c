#include "litos.h"

void on_save_as_response(GFile *file, struct lit *litos);
void open_file (GFile *file, gpointer userData);
void menu_save (gpointer userData);
void save_as_dialog(struct lit *litos);
void save_as_file(GtkFileChooser *chooser, struct lit *litos);
GtkSourceView* currentTabSourceView(struct lit *litos);
void menu_newtab (GtkWidget *widget, gpointer userData);
void freePage(int page, struct lit *litos);
GtkTextBuffer* get_current_buffer(struct lit *litos);
void clear_page_buffer(struct lit *litos);

void action_save_as_dialog_cb (GtkWidget *dialog, gint response, gpointer userData)
{
	struct lit *litos = (struct lit*)userData;

	GtkFileChooser *chooser = GTK_FILE_CHOOSER (dialog);

	//gtk_file_chooser_set_do_overwrite_confirmation (chooser, TRUE);

	if (response == GTK_RESPONSE_ACCEPT)
	{
		g_autoptr (GFile) file = gtk_file_chooser_get_file(chooser);
		on_save_as_response (file, litos);
	}

	g_object_unref(dialog);
}

void action_save_as_dialog (GSimpleAction *action, GVariant *parameter, void* userData)
{
	(void)action;
	(void)parameter;

	struct lit *litos = (struct lit*)userData;

	GtkWidget *dialog = gtk_file_chooser_dialog_new ("Save File",
		                                  GTK_WINDOW(litos->window),
		                                  GTK_FILE_CHOOSER_ACTION_SAVE,
		                                  _("_Cancel"),
		                                  GTK_RESPONSE_CANCEL,
		                                  _("_Save"),
		                                  GTK_RESPONSE_ACCEPT,
		                                  NULL);

	g_signal_connect (dialog, "response", G_CALLBACK (action_save_as_dialog_cb), litos);
}

void saveornot_dialog_button_clicked_cb (GtkWidget *dialog, gint response, gpointer userData)
{
	struct lit *litos = (struct lit*)userData;

	const int totalPages = gtk_notebook_get_n_pages(litos->notebook);

	switch (response)
	{
		case GTK_RESPONSE_CANCEL:
			break;

		case GTK_RESPONSE_ACCEPT:
			menu_save(litos);
			break;

		case GTK_RESPONSE_REJECT:
			if (totalPages == 1)
				clear_page_buffer(litos);
			else
			{
				freePage(litos->page, litos);
				gtk_notebook_remove_page(litos->notebook, litos->page);
			}

			break;

		default: /*close bottun was pressed*/
			g_print("The bottun(Close without Saving/Cancel/Save) was not pressed.");
	}

	g_object_unref(dialog);
}

void open_dialog_button_clicked_cb (GtkWidget *dialog, gint response, gpointer userData)
{
	struct lit *litos = (struct lit*)userData;

	if (response == GTK_RESPONSE_ACCEPT)
	{
		GtkTextBuffer *buffer = get_current_buffer(litos);
		GFile *file = gtk_file_chooser_get_file (GTK_FILE_CHOOSER (dialog));

		if (litos->filename[0] != NULL)
		{
			int total_pages = gtk_notebook_get_n_pages(litos->notebook);

			int i;

			for (i = 0; i < total_pages; i++)	/* Check whether the file is already opened: in positive case focus on its tab */
			{
				if (litos->filename[i] == NULL)
					continue;

				else
				{
					if (strcmp(litos->filename[i],g_file_get_path (file)) == 0)
					{
						gtk_notebook_set_current_page (litos->notebook,i);
						gtk_widget_grab_focus(GTK_WIDGET(currentTabSourceView(litos)));

						g_object_unref(file);

						return;
					}
				}
			}
		}
 
		if ((gtk_text_buffer_get_char_count(buffer)) != 0)
		{
			menu_newtab(NULL, litos);
			litos->filename[litos->page] = g_file_get_path(file);
		}

		else
			litos->filename[litos->page] = g_file_get_path(file);	

		g_object_unref(file);
		open_file (file, litos);
	}

	g_object_unref(dialog);
}

void openFromTemplate_dialog_button_clicked_cb (GtkWidget *dialog, gint response, gpointer userData)
{
	struct lit *litos = (struct lit*)userData;

	if (response == GTK_RESPONSE_ACCEPT)
	{
		GtkTextBuffer *buffer = get_current_buffer(litos);

		if ((gtk_text_buffer_get_char_count(buffer)) != 0)
			menu_newtab(NULL, litos);

		GFile *file = gtk_file_chooser_get_file (GTK_FILE_CHOOSER (dialog));

		g_object_unref(file);

		litos->isTemplate = TRUE;

		open_file (file, litos);
	}

	g_object_unref(dialog);
}

gboolean saveornot_before_close(struct lit *litos)
{
	GtkWidget *dialog;

	dialog = gtk_message_dialog_new(GTK_WINDOW(litos->window), GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING,
                      GTK_BUTTONS_NONE, "Save changes to document %s before closing?", litos->filename[litos->page]);

	gtk_dialog_add_buttons (GTK_DIALOG(dialog), "Close without Saving", GTK_RESPONSE_REJECT,
                                                      "Cancel", GTK_RESPONSE_CANCEL, "Save", GTK_RESPONSE_ACCEPT,  NULL);

	g_signal_connect (dialog, "response", G_CALLBACK (saveornot_dialog_button_clicked_cb), litos);

	return TRUE;
}

void open_dialog (GtkWidget *widget, gpointer userData)
{
	(void)widget;

	struct lit *litos = (struct lit*)userData;
 
	GtkWidget *dialog;

	dialog = gtk_file_chooser_dialog_new ("Open File",
		GTK_WINDOW(litos->window),
		GTK_FILE_CHOOSER_ACTION_OPEN,
		_("_Cancel"),
		GTK_RESPONSE_CANCEL,
		_("_Open"),
		GTK_RESPONSE_ACCEPT,
		NULL);

	//if (litos->filename[litos->page] != NULL) 	/* To let Open dialog show the files within current DIR of file already opened
	//{
	
	//	gtk_file_chooser_set_current_folder(GTK_FILE_CHOOSER (dialog), g_path_get_dirname(litos->filename[litos->page]), NULL);
	//}

	g_signal_connect (dialog, "response", G_CALLBACK (open_dialog_button_clicked_cb), litos);
}

void openFromTemplate (GtkWidget *widget, gpointer userData)
{
	(void)widget;

	struct lit *litos = (struct lit*)userData;

	GtkWidget *dialog = gtk_file_chooser_dialog_new ("Open File",
                                      GTK_WINDOW(litos->window),
                                      GTK_FILE_CHOOSER_ACTION_OPEN,
                                      _("_Cancel"),
                                      GTK_RESPONSE_CANCEL,
                                      _("_Open"),
                                      GTK_RESPONSE_ACCEPT,
                                      NULL);

	g_signal_connect (dialog, "response", G_CALLBACK (openFromTemplate_dialog_button_clicked_cb), litos);
}

void about_dialog (GtkButton *button, gpointer userData)
{
	(void)button;
	(void)userData;

	const gchar *authors[] = {"Giovanni Resta", "giovannirestadev@gmail.com", NULL};

	gtk_show_about_dialog (NULL,
			"program-name", "Litos",
			"version", "3.2",
			"license-type", GTK_LICENSE_GPL_3_0,
			"website", "https://github.com/gioretikto/litos",
			"authors", authors,
			"logo-icon-name", "start-here",
			"title", ("Litos"),
			NULL);
}
