#include "litos.h"

void searchWord (GtkButton *button, gpointer userData);
void replaceButtonClicked (GtkButton *button, gpointer userData);
void open_dialog (GtkWidget *widget, gpointer userData);
void openFromTemplate (GtkWidget *widget, gpointer userData);
void action_save_as_dialog(struct lit *litos);
void menu_save (GtkWidget *widget, gpointer userData);
void menu_newtab (GtkWidget *widget, gpointer userData);

GtkWidget *search_entry, *replace_entry, *button_check_case;
GtkWidget *lbl_number_occurences;

void createSearchPopover(GtkMenuButton *search_menu_button, struct lit *litos)
{
	GtkWidget *vbox, *hbox_search, *hbox_replace, *label_search, *label_replace, *search_button, *replace_button, *popover;

	label_search = gtk_label_new ("Search:");
	label_replace = gtk_label_new ("Replace:");

	lbl_number_occurences= gtk_label_new (NULL);

	search_button = gtk_button_new_with_label("Search");
	replace_button = gtk_button_new_with_label("Replace All");

	vbox = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
	hbox_search = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	hbox_replace = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 0);
	button_check_case = gtk_check_button_new_with_mnemonic(_("_Match case\t"));

	search_entry = gtk_entry_new ();
	replace_entry = gtk_entry_new ();

	gtk_box_append(GTK_BOX(vbox), hbox_search);
	gtk_box_append(GTK_BOX(vbox), hbox_replace);

	gtk_box_append(GTK_BOX(hbox_search), label_search);
	gtk_box_append(GTK_BOX(hbox_search), search_entry);
	gtk_box_append(GTK_BOX(hbox_search), search_button);
	gtk_box_append(GTK_BOX(hbox_search), button_check_case);
	gtk_box_append(GTK_BOX(hbox_search), lbl_number_occurences);

	gtk_box_append(GTK_BOX(hbox_replace), label_replace);
	gtk_box_append(GTK_BOX(hbox_replace), replace_entry);
	gtk_box_append(GTK_BOX(hbox_replace), replace_button);

	popover = gtk_popover_new ();

	gtk_popover_set_child(GTK_POPOVER(popover), vbox);

	gtk_menu_button_set_popover (search_menu_button, popover);
	gtk_popover_set_position (GTK_POPOVER (popover), GTK_POS_RIGHT);
	
	gtk_widget_show (vbox);

	g_signal_connect (search_button, "clicked", G_CALLBACK (searchWord), litos);
	g_signal_connect (replace_button, "clicked", G_CALLBACK (replaceButtonClicked), litos);
}

void createFilePopover (GtkWidget *parent, GtkPositionType pos, struct lit *litos)
{
  	GtkWidget *file_box, *new_tab_button, *open_button, *new_from_template_button, *save_button, *save_as_button;

	GtkWidget *popover;

	popover = gtk_popover_new ();
	gtk_popover_set_position (GTK_POPOVER (popover), pos);

	gtk_menu_button_set_popover (GTK_MENU_BUTTON(parent), popover);
	//gtk_container_set_border_width (GTK_CONTAINER (popover), 6);
  
	file_box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);

	gtk_popover_set_child(GTK_POPOVER(popover), file_box);

	new_tab_button = gtk_button_new_with_label("New Tab");
	open_button = gtk_button_new_with_label("Open");
	new_from_template_button = gtk_button_new_with_label("New From Template");
	save_button = gtk_button_new_with_label("Save");
	save_as_button = gtk_button_new_with_label("Save As");

	gtk_box_append(GTK_BOX(file_box), open_button);
	gtk_box_append(GTK_BOX(file_box), new_from_template_button);
	gtk_box_append(GTK_BOX(file_box), save_button);
	gtk_box_append(GTK_BOX(file_box), save_as_button);

	g_signal_connect (new_tab_button, "clicked", G_CALLBACK (menu_newtab), litos);
	g_signal_connect (open_button, "clicked", G_CALLBACK (open_dialog), litos);
	g_signal_connect (new_from_template_button, "clicked", G_CALLBACK (openFromTemplate), litos);
	gtk_actionable_set_action_name(GTK_ACTIONABLE(save_as_button), "app.save_as");
	g_signal_connect (save_button, "clicked", G_CALLBACK (menu_save), litos);

	gtk_widget_show (file_box);
}
